// src/pages/parent/ParentDashboard.tsx
// TODO: Implement ParentDashboard — see CLAUDE.md and .claude/agents/ for full spec

export default function ParentDashboard() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <div className="text-center">
        <p className="text-4xl mb-4">🚧</p>
        <h2 className="text-xl font-bold text-gray-800 mb-2">ParentDashboard</h2>
        <p className="text-gray-500 text-sm">
          This page is scaffolded and ready to build.
          See CLAUDE.md for the full spec.
        </p>
      </div>
    </div>
  );
}
